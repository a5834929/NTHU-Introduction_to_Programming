#include <stdio.h>
#include <stdlib.h> 
#include <time.h>   
#include <string.h>
#include <windows.h>
#include <mmsystem.h>
/* For sound effect: In [Project Options]->[Parameters]->[Linker] add the parameter -lwinmm */

#include "console_draw2.h"  
#include "kb_input2.h"
/* 
putASCII2()  �̫��ӰѼƤ��O�O�r���e���M�I�����C��
�i�H�ѦҤU�����C��ȹ�Ӫ��ӳ]�w�A�Q�n���C��     
   0: ��     1: �t��   2: �t��   3: �t�C 
   4: �t��   5: �t��   6: �t��   7: �L��
   8: �t��   9: �G��  10: �G��  11: �G�C
  12: �G��  13: �G��  14: �G��  15: ��   
*/ 

#define WIDTH     20
#define HEIGHT    20   
#define OFFSET_X  3
#define OFFSET_Y  3 

int plate[HEIGHT+1][WIDTH] = {0};

/* �۩w�� struct   �ΨӴy�z������U���ݩ� */ 
struct block {
   int x;
   int y;
   int color;
   int duration;
   int shape[3][3];
};

void delay(float sec); 
void putString(int x, int y, char *p, int fg_color, int bg_color);

void genBlock(struct block *blk);
void showBlock(struct block *blk);
int moveBlock(struct block *blk, int newx, int newy);
void fillPlate(struct block *blk);
int rotateBlock(struct block *blk);
void checkPlate(void);
int autoPlay(struct block *blk);

int score;

int main(void) 
{    
   int IsEnding = 0;
   char logo[] = "SAMPLE PROGRAM PROVIDED BY I2P11";
   int i, j;
   int vk;
   int stopped = 1;
   struct block blk;
   clock_t startc;    
   int tick = 0;
   char str[80];
   int IsAuto = 1;
   
   /* �Q�W���䪺����M�̩��U���a�O�@*/ 
   for (i = 0; i < HEIGHT; i++) {
      plate[i][0] = 1;
      plate[i][WIDTH-1] = 1;
   }
   for (j = 0; j < WIDTH; j++) {
      plate[HEIGHT-1][j] = 1;
      plate[HEIGHT][j] = 1;
   }

   /* ���Ͷü� seed    ���᭱�I�s rand() �i�H�o�줣�P���üƧǦC  */ 
   srand(time(NULL));   

   /* �Ψӭp�� */ 
   startc = clock();

   /* �Ұ���L���� */ 
   initializeKeyInput(); 
   
	/* �L�a�j��  �̭��]�t�F�o�ӵ{�����D�n�u�@   
   �ӥB�C���j��|���_��̷s���e����ܨ�ù��W  ���O���ʵe�@�� �C���j���s�@���e�� */
   while (!IsEnding) { 

      /* �ۤv�]�w���ɶ���� tick  �C 0.01 ����@�� tick   �᭱�|�Q�� tick �ƨӨM�w������ʳt�� */ 
      if ((double)(clock()-startc) > 0.005*CLOCKS_PER_SEC) {
         tick++;
         startc = clock();
      }


      /* ��W�ť� �M����ӿù��e�� */ 
      for (i = 0; i < HEIGHT; i++) {
         for (j = 0; j < WIDTH*2; j++) {            
            putASCII2(j + OFFSET_X, i + OFFSET_Y, ' ', 0, 0);
         }
      } 
      
      /* ��ثe�C�����p �� putASCII2() ��ܥX�� */ 
      for (i = 0; i < HEIGHT; i++) {
         for (j = 0; j < WIDTH; j++) {
            if (plate[i][j] == 1) {
               putASCII2(j*2 + OFFSET_X, i + OFFSET_Y, 0xA1, 8, 0);  /* fg_color=8 �N���e�����C��O�Ǧ� */ 
               putASCII2(j*2+1 + OFFSET_X, i + OFFSET_Y, 0xBD, 8, 0);
            } else {
               putASCII2(j*2 + OFFSET_X, i + OFFSET_Y, ' ', 0, 0);
               putASCII2(j*2+1 + OFFSET_X, i + OFFSET_Y, ' ', 0, 0);
            }
         }
      } 

       /* ���p block �w�g�I��a�O�Ӱ���  �N���ͷs�� block   �åB�� stopped ���A�M�� */ 
      if (stopped) {    
         genBlock(&blk);
         stopped = moveBlock(&blk, blk.x, blk.y+1); 
         if (stopped)
            break;   
         if (IsAuto)
            blk.duration = 15; 
      }
      
      /* �� block ��ܨ�ù��W */ 
      showBlock(&blk); 
      
           
      /*  �� logo �� putString() ��ܥX�� 
         putString() �O�۩w�� function    ����b�S�w��m��ܦr�� 
         �o�� function ���{���X�]��b�o���ɮ׸�  �b main() ���� 
         �{���X����²�u  �u�O�b�j��̩I�s putASCII2() �Ӥw       */ 
      putString(OFFSET_X, OFFSET_Y-2, logo, 14, 3);
      sprintf(str, "Score: %d", score);
      putString(OFFSET_X, OFFSET_Y-1, str, 14, 3);


      /* ���F�n���@�s�� putASCII2() ���ʧ@���ͮĪG  
         �����n�I�s�@�� drawCmdWindow() �⤧�e�e���������e�@����ܨ�ù��W */ 
      drawCmdWindow();      


      /* ��L���� */ 
      if(waitForKeyDown(0.01)) {
         vk=getKeyEventVirtual();	/* read a virtual key */	  

         switch(vk) { 
            case VK_SHIFT:
               IsAuto = !IsAuto;
               break;
            case VK_ESCAPE:  /* ���U ESC �� �N���� */ 
               IsEnding = 1; 
               break;
            case VK_LEFT: 
               moveBlock(&blk, blk.x - 1, blk.y); 
               break;
            case VK_RIGHT: 
               moveBlock(&blk, blk.x + 1, blk.y); 
               break;
            case VK_DOWN: 
               blk.duration = 1;
               break;
            case VK_CONTROL:  /* ���U Ctrl ��  ���ӭn���� block */ 
               rotateBlock(&blk);
               break;              
         }      
      }
      
      
      /* blk.duration ����C���n���ʪ��ɶ����j     tick �O�e���۩w���p�ɳ�� ������ 0.01 �� */ 
      if (tick % blk.duration == 0)  { 
         /* ���� block  �åB�|�P�_�O�_�O�X�k������  �H�άO�_�w�g�Q��L block �צ�*/           
                  
         if (IsAuto) 
            stopped = moveBlock(&blk, blk.x+autoPlay(&blk), blk.y+1); 
         else
            stopped = moveBlock(&blk, blk.x, blk.y+1); 
      }

      /* �p�G�Q�צ�  �ثe�� block �N�n�ܦ� plate ���@���� */ 
      if (stopped) {
         fillPlate(&blk);
      }
      
 
      checkPlate();      

                         
                                   
   } /* while (1) */      
 

   delay(0.5);   
   return 0; 
} 




/* ���{���Ȱ� sec �� */ 
void delay(float sec)
{
   clock_t startc;    
   startc = clock();
   for ( ; ; ) {	
	  if ((float)(clock()-startc)/CLOCKS_PER_SEC > sec) break;
   } 	 
} 
/* �b (x, y) �y�Ъ���m��ܦr�� p �����e  fg_color �O�e�����C��  bg_color �h�O�I�����C�� */ 
void putString(int x, int y, char *p, int fg_color, int bg_color)
{
   int i;
   for(i=0; i<strlen(p); i++) {
      putASCII2(x+i, y, p[i], fg_color, bg_color);
   }
}


/****************************************************************************************************/

void genBlock(struct block *pblk)
{  
   pblk->x = WIDTH/2-1;
   pblk->y = 0;
   pblk->color = rand()%7 + 9; /* �u�� 7 �ثG�� */ 
   pblk->duration = 60;
   switch (rand()%6) {
      case 0:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 1; pblk->shape[1][1] = 0; pblk->shape[1][2] = 0; 
         pblk->shape[2][0] = 1; pblk->shape[2][1] = 1; pblk->shape[2][2] = 1;
         break;
      case 1:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 1; pblk->shape[1][1] = 1; pblk->shape[1][2] = 0; 
         pblk->shape[2][0] = 1; pblk->shape[2][1] = 1; pblk->shape[2][2] = 0;
         break;
      case 2:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 1; pblk->shape[1][1] = 1; pblk->shape[1][2] = 0; 
         pblk->shape[2][0] = 0; pblk->shape[2][1] = 1; pblk->shape[2][2] = 1;
         break;
      case 3:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 0; pblk->shape[1][1] = 1; pblk->shape[1][2] = 0; 
         pblk->shape[2][0] = 1; pblk->shape[2][1] = 1; pblk->shape[2][2] = 1;
         break;
      case 4:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 0; pblk->shape[1][1] = 0; pblk->shape[1][2] = 1; 
         pblk->shape[2][0] = 1; pblk->shape[2][1] = 1; pblk->shape[2][2] = 1;
         break;
      case 5:
         pblk->shape[0][0] = 0; pblk->shape[0][1] = 0; pblk->shape[0][2] = 0;
         pblk->shape[1][0] = 0; pblk->shape[1][1] = 1; pblk->shape[1][2] = 1; 
         pblk->shape[2][0] = 1; pblk->shape[2][1] = 1; pblk->shape[2][2] = 0;
         break;
   }
   
}

void showBlock(struct block *pblk)
{
   int i, j;
   for (i = 0; i < 3; i++) {
      for (j = 0; j < 3; j++) { 
         if (pblk->shape[i][j] == 1) {
            putASCII2((pblk->x+j)*2 + OFFSET_X, (pblk->y+i) + OFFSET_Y, 0xA1, pblk->color, 0);
            putASCII2((pblk->x+j)*2 + 1 + OFFSET_X, (pblk->y+i) + OFFSET_Y, 0xBD, pblk->color, 0);   
         }
      }
   } 
   
} 

int moveBlock(struct block *blk, int newx, int newy)
{
   int i, j;
   int valid_move = 1;
   
   for (i = 0; i < 3; i++) {
      for (j = 0; j < 3; j++) {
         if (blk->shape[i][j] && plate[newy+i][newx+j])
            valid_move = 0;
      }
   } 
   if (valid_move) {
      blk->x = newx;
      blk->y = newy;
   } else if (blk->y < newy) {
      return 1; /* stopped by some blocks underneath */
   }
   return 0;      
}

void fillPlate(struct block *blk)
{
   int i, j;

   for (i = 0; i < 3; i++) {
      for (j = 0; j < 3; j++) {         
         plate[blk->y+i][blk->x+j] = plate[blk->y+i][blk->x+j] | blk->shape[i][j];  /* bit operator OR*/
      }
   } 
}


int rotateBlock(struct block *blk)
{
   int i, j;
   int idx[] = {2, 5, 8, 1, 4, 7, 0, 3, 6};
   int tmp[3][3];
      
   for (i = 0; i < 9; i++) {
      *(&tmp[0][0] + i) = *(&blk->shape[0][0] + idx[i]);
   } 
   for (i = 0; i < 3; i++) {
      if (tmp[i][0] && plate[blk->y+i][blk->x]) {
         blk->x++;
         break;
      }
   }
   for (i = 0; i < 3; i++) {
      if (tmp[i][2] && plate[blk->y+i][blk->x+2]) {
         blk->x--;
         break;
      }
   }
   for (i = 0; i < 3; i++) {   
      if (tmp[2][i] && plate[blk->y+2][blk->x+i]) {
         blk->y--;
         break;
      } 
   }
   

   for (i = 0; i < 9; i++) {
      *(&blk->shape[0][0] + i) = *(&tmp[0][0] + i);
   } 
   

   return 0;      
}


void checkPlate(void)
{
   int i, j, cut, t=0;

   for (i = HEIGHT-2; i > 1; i--) {
      cut = 1;
      for (j = 1; j < WIDTH-1; j++) {         
         if (!plate[i][j]) {
            cut = 0;
            break;
         }
      }
      if (cut) {
         t = i;
         score++;
         break;
      }
   } 
   for (i = t; i > 1; i--) {
      for (j = 1; j < WIDTH-1; j++) {         
         plate[i][j] = plate[i-1][j];
      }
   }
}

int autoPlay(struct block *blk)
{
   int i, j, k, m, n;
   int stopped;
   int best_i = 1, best_j = 1, best_k = 0;
   int best_value=0;
   int value;
   struct block tmp_blk;
   
   for (j=1; j<WIDTH-2; j++) {
      
      tmp_blk.x = blk->x;
      tmp_blk.y = blk->y;
      for (m=0; m<3; m++) {
         for (n=0; n<3; n++) {
            tmp_blk.shape[m][n] = blk->shape[m][n];
         }
      }
      for (k=0; k<3; k++) {
         for (i=1; i<HEIGHT-1; i++) {
            stopped = moveBlock(&tmp_blk, j, i);
            if (stopped) break;
            if  (tmp_blk.x == j && tmp_blk.y == i) {                   
               value = 0;
               
               for (m=0; m<3; m++) {
                  for (n=0; n<3; n++) {
                     if (plate[tmp_blk.y+m][tmp_blk.x+n]) {      
                        value = value + 5*m;
                     }
                     
                     if (tmp_blk.shape[m][n])
                        value = value + 10*m;
                  }
               }

                  value = value + 18*i;


               
               if (value > best_value) {
                  best_value = value;
                  best_i = i;
                  best_j = j;
                  best_k = k;
               }          
                    
            }
         }
         rotateBlock(&tmp_blk);
      }
   } 

   for (k=0; k<best_k; k++) 
      rotateBlock(blk);
   

   return best_j-blk->x;
/*
   if (best_j > blk->x)
      return 1;
   else if (best_j < blk->x)
      return -1;
   else
      return 0;
*/
 
}
